I solved the tests as good as I could.
In each subfolder (1,2,3) there is an index.html with some minimal testing
Replies in test 1 questions can be found in 1/readme.txt.
I would appreciate any feedback.
Regards,
Yannis


you will find three small tests.
please solve them as good as you can and send me your solutions, as soon as you are done.

thx,
greets, andreas with team bitpanda