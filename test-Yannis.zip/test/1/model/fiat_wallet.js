"use strict";
var FiatWallet = /** @class */ (function () {
    function FiatWallet() {
        this.id = "";
        this.fiat_id = "";
        this.balance = "";
        this.name = "";
        //digits after "."
        this.digitsAfter = 2;
        //what happens when there is not enough balance to reduce?
        this.allowNegativeBalance = true;
    }
    FiatWallet.prototype.getId = function () {
        return this.id;
    };
    FiatWallet.prototype.setId = function (s) {
        this.id = s;
    };
    FiatWallet.prototype.getFiatId = function () {
        return this.fiat_id;
    };
    FiatWallet.prototype.setFiatId = function (id) {
        this.fiat_id = id;
    };
    FiatWallet.prototype.reduceBalance = function (amount) {
        //todo implement me
        if (isNaN(amount)) {
            return;
        }
        //should use add to increase, no negative numbers. Should flag by returning a code..
        if (amount <= 0) {
            return;
        }
        if (amount <= this.getBalance() || this.allowNegativeBalance) {
            this.setBalance(this.getBalance() - amount);
        }
        else {
            //? Allow a transaction resulting to a neg balance to the amount which can be covered or drop alltogether?
            //this would need a return code and handling..
        }
    };
    FiatWallet.prototype.addBalance = function (amount) {
        //todo implement me
        if (isNaN(amount)) {
            return;
        }
        //should use reduce to decrease, no negative numbers. Should flag by returning a code..
        if (amount <= 0) {
            return;
        }
        if (isNaN(this.getBalance())) {
            this.setBalance(0);
        }
        this.setBalance(this.getBalance() + amount);
    };
    FiatWallet.prototype.getName = function () {
        return this.name;
    };
    FiatWallet.prototype.setBalance = function (balance) {
        //todo implement me
        //check number for validity
        if (isNaN(balance)) {
            return;
        }
        //Is neg. balance allowed? 
        if (balance < 0 && !this.allowNegativeBalance) {
            return;
        }
        this.balance = balance.toFixed(this.digitsAfter);
    };
    FiatWallet.prototype.getBalance = function () {
        //todo implement me
        var theBalance = Number(this.balance);
        if (!isNaN(theBalance)) {
            return theBalance;
        }
        return 0;
    };
    return FiatWallet;
}());
