"use strict";
var CryptoWallet = /** @class */ (function () {
    function CryptoWallet() {
        this.id = "";
        this.cryptocoin_id = "";
        this.is_default = false;
        this.balance = "";
        //digits after "."
        this.digitsAfter = 2;
        //what happens when there is not enough balance to reduce?
        this.allowNegativeBalance = true;
    }
    CryptoWallet.prototype.getId = function () {
        return this.id;
    };
    CryptoWallet.prototype.setId = function (s) {
        this.id = s;
    };
    CryptoWallet.prototype.isDefault = function () {
        return this.is_default;
    };
    CryptoWallet.prototype.getCryptocoinId = function () {
        return this.cryptocoin_id;
    };
    CryptoWallet.prototype.setCryptocoinId = function (id) {
        this.cryptocoin_id = id;
    };
    CryptoWallet.prototype.setDefault = function (b) {
        this.is_default = b;
    };
    CryptoWallet.prototype.reduceBalance = function (amount) {
        //todo implement me
        if (isNaN(amount)) {
            return;
        }
        //should use add to increase, no negative numbers. Should flag by returning a code..
        if (amount <= 0) {
            return;
        }
        if (amount <= this.getBalance() || this.allowNegativeBalance) {
            this.setBalance(this.getBalance() - amount);
        }
        else {
            //? Allow the transaction to the amount which can be covered or drop alltogether?
        }
    };
    CryptoWallet.prototype.addBalance = function (amount) {
        //todo implement me
        if (isNaN(amount)) {
            return;
        }
        //should use reduce to decrease, no negative numbers. Should flag by returning a code..
        if (amount <= 0) {
            return;
        }
        if (isNaN(this.getBalance())) {
            this.setBalance(0);
        }
        this.setBalance(this.getBalance() + amount);
    };
    CryptoWallet.prototype.setBalance = function (balance) {
        //todo implement me
        //check number for validity
        if (isNaN(balance)) {
            return;
        }
        //Is neg. balance allowed? 
        if (balance < 0 && !this.allowNegativeBalance) {
            return;
        }
        this.balance = balance.toFixed(this.digitsAfter);
    };
    CryptoWallet.prototype.getBalance = function () {
        //todo implement me
        var theBalance = Number(this.balance);
        if (!isNaN(theBalance)) {
            return theBalance;
        }
        return 0;
    };
    return CryptoWallet;
}());
