class FiatWallet {

    id: string = "";
    fiat_id: string = "";
    balance: string = "";
    name: string = "";
    //digits after "."
    private readonly digitsAfter:number=2;
    //what happens when there is not enough balance to reduce?
    private readonly allowNegativeBalance:boolean=true;

    public getId(): string {
        return this.id;
    }

    public setId(s: string): void {
        this.id = s;
    }

    public getFiatId(): string {
        return this.fiat_id;
    }

    public setFiatId(id: string): void {
        this.fiat_id = id;
    }

    public reduceBalance(amount: number): void {
        //todo implement me
        if (isNaN(amount)) { return; }
        //should use add to increase, no negative numbers. Should flag by returning a code..
        if(amount<=0) {return;}

        if(amount<=this.getBalance() || this.allowNegativeBalance)
        {
            this.setBalance(this.getBalance() - amount);            
        }
        else
        {
            //? Allow a transaction resulting to a neg balance to the amount which can be covered or drop alltogether?
            //this would need a return code and handling..
        }
    }

    public addBalance(amount: number): void {
        //todo implement me
        if (isNaN(amount)) { return; }
        //should use reduce to decrease, no negative numbers. Should flag by returning a code..
        if(amount<=0) {return;}

        if(isNaN(this.getBalance())) {this.setBalance(0);}

        this.setBalance(this.getBalance() + amount);

    }

    public getName(): string {
        return this.name;
    }

    public setBalance(balance: number): void {
        //todo implement me
        //check number for validity
        if (isNaN(balance)) { return; }
        
        //Is neg. balance allowed? 
         if(balance<0 && !this.allowNegativeBalance) {return;}

        this.balance = balance.toFixed(this.digitsAfter);

    }

    public getBalance(): number {
        //todo implement me
        let theBalance=Number(this.balance);

        if(!isNaN(theBalance))
        {
            return theBalance;
        }
        return 0;
    }
}
