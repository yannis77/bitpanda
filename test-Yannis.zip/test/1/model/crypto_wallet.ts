class CryptoWallet {

    id: string = "";
    cryptocoin_id: string = "";
    is_default: boolean = false;
    balance: string = "";
    //digits after "."
    private readonly digitsAfter:number=2;
    //what happens when there is not enough balance to reduce?
    private readonly allowNegativeBalance:boolean=true;

    public getId(): string {
        return this.id;
    }

    public setId(s: string): void {
        this.id = s;
    }

    public isDefault(): boolean {
        return this.is_default;
    }

    public getCryptocoinId(): string {
        return this.cryptocoin_id;
    }

    public setCryptocoinId(id: string): void {
        this.cryptocoin_id = id;
    }

    public setDefault(b: boolean): void {
        this.is_default = b;
    }

    public reduceBalance(amount: number): void {
        //todo implement me
        if (isNaN(amount)) { return; }
        //should use add to increase, no negative numbers. Should flag by returning a code..
        if(amount<=0) {return;}

        if(amount<=this.getBalance() || this.allowNegativeBalance)
        {
            this.setBalance(this.getBalance() - amount);            
        }
        else
        {
            //? Allow the transaction to the amount which can be covered or drop alltogether?
        }
    }

    public addBalance(amount: number): void {
        //todo implement me
        if (isNaN(amount)) { return; }
        //should use reduce to decrease, no negative numbers. Should flag by returning a code..
        if(amount<=0) {return;}

        if(isNaN(this.getBalance())) {this.setBalance(0);}

        this.setBalance(this.getBalance() + amount);

    }


    public setBalance(balance: number): void {
        //todo implement me
        //check number for validity
        if (isNaN(balance)) { return; }
        
        //Is neg. balance allowed? 
         if(balance<0 && !this.allowNegativeBalance) {return;}

        this.balance = balance.toFixed(this.digitsAfter);

    }

    public getBalance(): number {
        //todo implement me
        let theBalance=Number(this.balance);

        if(!isNaN(theBalance))
        {
            return theBalance;
        }
        return 0;
    }
}
