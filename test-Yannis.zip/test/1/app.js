"use strict";
var rc = "";
function goTest() {
    var mm = new CryptoWallet;
    rc += "Balance:";
    rc += mm.getBalance() + "<br>";
    rc += "Setting balance to 1250.67 <br>";
    mm.setBalance(1250.67);
    rc += "Balance: " + mm.getBalance() + "<br>";
    rc += "Adding 1<br>";
    mm.addBalance(1);
    rc += "Balance:" + mm.getBalance() + "<br>";
    rc += "Adding -1<br>";
    mm.addBalance(-1);
    rc += "Balance:" + mm.getBalance() + "<br>";
    rc += "Withdrawing 1000<br>";
    mm.reduceBalance(1000);
    rc += "Balance:" + mm.getBalance() + "<br>";
    rc += "Withdrawing -5000<br>";
    mm.reduceBalance(-5000);
    rc += "Balance:" + mm.getBalance() + "<br>";
    rc += "Withdrawing 500<br>";
    mm.reduceBalance(500);
    rc += "Balance:" + mm.getBalance() + "<br>";
}
goTest();
document.body.innerHTML = rc;
