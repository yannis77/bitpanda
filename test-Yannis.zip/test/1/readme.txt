Please implement the missing parts!

How would you improve those classes? What can you generalise?

0. I would make a class "Wallet", probably abstract, and both Crypto- and Fiat-wallet would inherit from that. Most methods
could be only implemented in Wallet. 

1. I would add a currency - money type/ interface, and respective generalized classes, to represent currency, operations on it and even currency conversions.
CryptoCurrency & FiatCurrency would extend that, depending on special requirement each has. Try to disallow adding/sub etc together
different currencies, etc. Crypto and EU or USD..
Attention would be needed though, as it would be passed around by reference..
Maybe use identity Functions.

*Depending on needs and concerns* (Accuracy? Size?), could store balance as integer value (satoshis / cents etc).

Add & subtract could work no problem, depending on other operations (interest calculation?), maybe no floating point needed.

I Would definetely make the "balance" member private and not allow it to be changed, except with get /set /add etc


2. I would make all member values private, access only through get - set.
3. I would make non-changeable members like ID etc. readonly,only settable by constructor
4. What happens when there is not enough balance? Do not permit the entire transaction or deduct the available and set balance to zero? 
5. I would add success and failure return codes to most functions and a return_code type (prob. using an enum).
6. I would add compareBalance() and enoughBalance()

7. I would lock transactions using a transaction ID, set externally before execution, and log to avoid double-transaction e.g.
on a reload or an accidental hit-twice or whatever might happen.


8. add default constructors, and constructors with parameters..

9. Add a lock option on wallets and relative member functions isLocked / lock /unlock etc 
