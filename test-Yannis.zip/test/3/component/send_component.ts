class SendComponent {

    /**
     * in the live code this is set after the view loaded; you can assume that this won't be null or empty
     * you can mock or change this if you want
     * @type {any}
     */
    contacts: Contact[] = null;
    //create some test data
    public populateContacts():void {
        this.contacts=[];
        
        var c1 = new Contact;
        c1.data = "A";
        c1.id = "id1";
        c1.last_used = new Time();
        c1.last_used.unix = "1517734110";
        this.contacts.push(c1);

        var c2 = new Contact;
        c2.data = "B";
        c2.id = "id2";
        c2.last_used = new Time();
        c2.last_used.unix = "1517734114";
        this.contacts.push(c2);

        var c3 = new Contact;
        c3.data = "C";
        c3.id = "id3";
        c3.last_used = new Time();
        c3.last_used.unix = "1517734110";
        this.contacts.push(c3);

        var c4 = new Contact;
        c4.data = "A";
        c4.id = "id4";
        c4.last_used = new Time();
        c4.last_used.unix = "1517734111";
        this.contacts.push(c4);

        var c5 = new Contact;
        c5.data = "A";
        c5.id = "id5";
        c5.last_used = new Time();
        c5.last_used.unix = "1517734112";
        this.contacts.push(c5);

	}
    /**
     * todo : returned list must
     * ) hold only unique entries (data NOT id)
     * ) hold max three entries
     * ) sorted by "last_used" (if you use a custom sort, i'd suggest to use the unix timestamp)
     * @returns {Contact[]}
     */
    get recentContacts(): Contact[] {
        //this is the array to be returned.
        let rCArray : Contact[]=[];
        //provide a sort function
        let timeSort = function (a:Contact, b: Contact) : number
            {
                if(a.getLastUsed().getUnix() > b.getLastUsed().getUnix())
                {return -1;}
                if(a.getLastUsed().getUnix() < b.getLastUsed().getUnix())
                {return 1;}
                return 0;
            };
        //get a copy of the member contacts array and sort it timewise, most recent first.
        let tempArray: Contact[]=this.contacts.slice().sort(timeSort);
        
        //go through the sorted array...
        for(let i=0;i<tempArray.length;i++)
        {   //Always need the first item.
            if(i==0)
            {
                rCArray.push(tempArray[0]);
            }
            else//entry might already be in the newArray
            {
                let doAdd=true;
                //go through the new Array..
                for(let n=0;n<rCArray.length;n++)
                {//and if the entry is already there, obviously fresher...
                    if(tempArray[i].getData()===rCArray[n].getData())
                    {//flag that we don't need it
                        doAdd=false;
                        //and stop looping
                        break;
                    }
                }//if the entry is not there add it now
                if(doAdd)
                {
                    rCArray.push(tempArray[i]);
                }
              
            }
            //as soon as we get our top 3 entries, return
            if(rCArray.length==3)
            {
                return rCArray; //could also break, return saves a couple of execution lines :) 
            }

        }
        //didn't get up tp 3 entries, return whatever we got.
        return rCArray;
    }

}