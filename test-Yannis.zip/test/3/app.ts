var rc:string="";
function goTest () : void
{

    let mc:SendComponent=new SendComponent();
    mc.populateContacts();


    rc+="<br>All Contacts<br>";

    for(let m=0;m<mc.contacts.length;m++)
    {
        rc+=mc.contacts[m].getData() + " " + mc.contacts[m].getLastUsed().getUnix() + "<br>";
    }

    rc+="<br>Recent Contacts<br>";

    let getResults:Contact[] =mc.recentContacts;
    
    for(let m=0;m<getResults.length;m++)
    {
        rc+=getResults[m].getData() + " " + getResults[m].getLastUsed().getUnix() + "<br>";
    }

}

goTest();

document.body.innerHTML = rc;//"Hello World";