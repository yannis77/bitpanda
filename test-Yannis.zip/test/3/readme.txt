Think of the given model "Contact".

Imagine having any number of contacts with these 'data' is: "A", "B" and "C" so your list last used contact-list might look like this:
 [A, A, B, A]

Implement the given function "recentContacts" in the service that returns list with these conditions

    ) unique field "data" (NOT id)

    ) max length has to be three (if the list has size two and duplicate entries, then the returned list mustn't hold both: for ["A", "A"] 
the list should return ["A"])

    ) sorted by "last_used" (most recent first, last recent last -> fifo)