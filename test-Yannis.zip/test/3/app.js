"use strict";
var rc = "";
function goTest() {
    var mc = new SendComponent();
    mc.populateContacts();
    rc += "<br>All Contacts<br>";
    for (var m = 0; m < mc.contacts.length; m++) {
        rc += mc.contacts[m].getData() + " " + mc.contacts[m].getLastUsed().getUnix() + "<br>";
    }
    rc += "<br>Recent Contacts<br>";
    var getResults = mc.recentContacts;
    for (var m = 0; m < getResults.length; m++) {
        rc += getResults[m].getData() + " " + getResults[m].getLastUsed().getUnix() + "<br>";
    }
}
goTest();
document.body.innerHTML = rc; //"Hello World";
