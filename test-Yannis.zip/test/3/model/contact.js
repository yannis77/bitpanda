"use strict";
/**
 * todo : nothing
 */
var Contact = /** @class */ (function () {
    function Contact() {
        this.id = "";
        this.data = "";
        this.last_used = new Time();
    }
    Contact.prototype.getData = function () {
        return this.data;
    };
    Contact.prototype.getLastUsed = function () {
        return this.last_used;
    };
    return Contact;
}());
