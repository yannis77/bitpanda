/**
 * this is a helper class; you can assume "unix" is a valid timestamp;
 * you can also use the date_iso8601 format if you are familiar with it
 * todo : nothing
 */
class Time {
    date_iso8601: string = "";
    unix: string = "";


    public getUnix(): number {
        return +this.unix;
    }

    public getDate(): string {
        return this.date_iso8601;
    }


}