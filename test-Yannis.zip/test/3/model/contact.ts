/**
 * todo : nothing
 */
class Contact {

    id: string = "";
    data: string = "";
    last_used: Time = new Time();

    public constructor() {
    }

    public getData(): string {
        return this.data;
    }

    public getLastUsed(): Time {
        return this.last_used;
    }
}
