"use strict";
/**
 * this is a helper class; you can assume "unix" is a valid timestamp;
 * you can also use the date_iso8601 format if you are familiar with it
 * todo : nothing
 */
var Time = /** @class */ (function () {
    function Time() {
        this.date_iso8601 = "";
        this.unix = "";
    }
    Time.prototype.getUnix = function () {
        return +this.unix;
    };
    Time.prototype.getDate = function () {
        return this.date_iso8601;
    };
    return Time;
}());
