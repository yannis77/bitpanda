/**
 * COMPONENT USING PROVIDED INTERFACE
 * if you implemented the walletservice correctly this class won't show any errors
 * todo : nothing!
 */
class TradeComponent {

    // this is just any value for test
    private min = 25;

    public constructor(private walletService: CryptoWalletService,
                       private fiatwalletService: FiatWalletService) {
    }

    get fiatWallets(): FiatWallet[] {
        return this.walletsWithFunds(this.min);
    }

    get cryptoWallets(): CryptoWallet[] {
        return this.walletService.wallets;
    }

    walletsWithFunds(min: number): FiatWallet[] {
        return this.fiatwalletService.wallets.filter(f => f.getBalance() >= (min));
    }


    noFiat(): boolean {
        return this.fiatwalletService.noBalance();
    }
}