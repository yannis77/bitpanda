"use strict";
/**
 * COMPONENT USING PROVIDED INTERFACE
 * if you implemented the walletservice correctly this class won't show any errors
 * todo : nothing!
 */
var TradeComponent = /** @class */ (function () {
    function TradeComponent(walletService, fiatwalletService) {
        this.walletService = walletService;
        this.fiatwalletService = fiatwalletService;
        // this is just any value for test
        this.min = 25;
    }
    Object.defineProperty(TradeComponent.prototype, "fiatWallets", {
        get: function () {
            return this.walletsWithFunds(this.min);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TradeComponent.prototype, "cryptoWallets", {
        get: function () {
            return this.walletService.wallets;
        },
        enumerable: true,
        configurable: true
    });
    TradeComponent.prototype.walletsWithFunds = function (min) {
        return this.fiatwalletService.wallets.filter(function (f) { return f.getBalance() >= (min); });
    };
    TradeComponent.prototype.noFiat = function () {
        return this.fiatwalletService.noBalance();
    };
    return TradeComponent;
}());
