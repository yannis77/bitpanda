"use strict";
var rc = "Hello World";
function goTest() {
}
goTest();
var cwm = new CryptoWalletService();
cwm.getNonEmptyWallets();
var mws = [];
var w1 = new CryptoWallet();
w1.id = "w1";
w1.setBalance(1250.25);
mws.push(w1);
cwm.wallets = mws;
var gw = cwm.getWalletById("w1");
document.body.innerHTML = "We have a wallet with id " + w1.getId() + " and balance " + w1.getBalance();
