
var rc:string = "Hello World";
function goTest() {
}
goTest();

let cwm : CryptoWalletService = new CryptoWalletService();

cwm.getNonEmptyWallets();

let mws:Wallet[] = [];

let w1:CryptoWallet=new CryptoWallet();
w1.id="w1";
w1.setBalance(1250.25);
mws.push(w1);
cwm.wallets=mws;
let gw:Wallet=cwm.getWalletById("w1");

document.body.innerHTML = `We have a wallet with id ${w1.getId()} and balance ${w1.getBalance()}`;
