"use strict";
//todo give the service type params that *only* allow sub-types of "Wallet"
var WalletService = /** @class */ (function () {
    function WalletService() {
        /**
         * you can assume this array won't be empty; it will be set correctly by a "masterservice"
         * if you want you can leave it or set it to "[]" emtpy
         * todo : change type param
         * @type {Wallet[]} please think of this type (sub type of class "Wallet" only)
         */
        this._wallets = []; //null;
    }
    /**
     * todo : return the wallet with wanted id
     * todo : change type param
     * @param {string} walletId the wanted id
     * @returns {Wallet}
     */
    WalletService.prototype.getWalletById = function (walletId) {
        if (!this.wallets) {
            return null;
        }
        for (var i = 0; i < this._wallets.length; i++) {
            if (this.wallets[i] && (this.wallets[i].id === walletId)) {
                return this.wallets[i];
            }
        }
        return null;
    };
    Object.defineProperty(WalletService.prototype, "wallets", {
        /**
         * todo : change type param
         * @returns {Wallet[]}
         */
        get: function () {
            return this._wallets;
        },
        /**
         * todo : change type param
         * @param {Wallet[]} w
         */
        set: function (w) {
            this._wallets = w;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * todo : change type param
     * todo : set in this._wallets the wallet with the given id (you can assume as pre-condition that this._wallets holds the given ID)
     * @param {Wallet} w
     * @param {string} walletId
     */
    WalletService.prototype.setWalletById = function (w /*CryptoWallet | FiatWallet*/, walletId) {
        if (!this.getWalletById(walletId)) {
            return;
        }
        for (var i = 0; i < this.wallets.length; i++) {
            if (this.wallets[i] && (this.wallets[i].id === walletId)) {
                this.wallets[i] = w;
                return;
            }
        }
        return;
    };
    /**
     * todo : return true if ANY wallet has balance > 0
     * @returns {boolean}
     */
    WalletService.prototype.noBalance = function () {
        if (!this.wallets) {
            return false;
        }
        for (var i = 0; i < this.wallets.length; i++) {
            if (this.wallets[i] && (this.wallets[i].getBalance() > 0)) {
                return true;
            }
        }
        return false;
    };
    WalletService.prototype.getNonEmptyWallets = function () {
        //todo: return any wallet with balance > 0
        if (!this.wallets) {
            return [];
        }
        var WBalance = [];
        for (var i = 0; i < this.wallets.length; i++) {
            if (this.wallets[i] && (this.wallets[i].getBalance() > 0)) {
                WBalance.push(this.wallets[i]);
            }
        }
        return WBalance;
    };
    return WalletService;
}());
