//todo give the service type params that *only* allow sub-types of "Wallet"
abstract class WalletService  {

    /**
     * you can assume this array won't be empty; it will be set correctly by a "masterservice"
     * if you want you can leave it or set it to "[]" emtpy
     * todo : change type param
     * @type {Wallet[]} please think of this type (sub type of class "Wallet" only)
     */
    protected _wallets: Wallet[] /*CryptoWallet[] | FiatWallet[]*/ = [];//null;

    constructor() {
    }

    /**
     * todo : return the wallet with wanted id
     * todo : change type param
     * @param {string} walletId the wanted id
     * @returns {Wallet}
     */
    public getWalletById(walletId: string): Wallet {
		if(!this.wallets){return null;}
		for (let i=0; i<this._wallets.length; i++){
			if(this.wallets[i] && (this.wallets[i].id === walletId)){
				return this.wallets[i];
			}
		}
		return null;
	}

    /**
     * todo : change type param
     * @returns {Wallet[]}
     */
    public get wallets(): Wallet[] {//CryptoWallet[] | FiatWallet[] {
        return this._wallets;
    }

    /**
     * todo : change type param
     * @param {Wallet[]} w
     */
    public set wallets(w: Wallet[]) {//CryptoWallet[] | FiatWallet[]) {
        this._wallets = w;
    }


    /**
     * todo : change type param
     * todo : set in this._wallets the wallet with the given id (you can assume as pre-condition that this._wallets holds the given ID)
     * @param {Wallet} w
     * @param {string} walletId
     */
    setWalletById(w: Wallet/*CryptoWallet | FiatWallet*/, walletId: string): void {
		if(!this.getWalletById(walletId)){return;}

		for (let i=0; i<this.wallets.length; i++){
			if(this.wallets[i] && (this.wallets[i].id === walletId)){
				this.wallets[i]=w;
				return;
			}
		}
		return;
    }

    /**
     * todo : return true if ANY wallet has balance > 0
     * @returns {boolean}
     */
    noBalance(): boolean {
		if(!this.wallets){return false;}

		for (let i=0; i<this.wallets.length; i++){
			if(this.wallets[i] && (this.wallets[i].getBalance()>0)){
				return true;
			}
		}
        return false;
    }

    public getNonEmptyWallets(): Wallet[] {//CryptoWallet[] | FiatWallet[] {
        //todo: return any wallet with balance > 0
		if(!this.wallets){return [];}
		let WBalance : Wallet[] =[];

		for (let i=0; i<this.wallets.length; i++){
			if(this.wallets[i] && (this.wallets[i].getBalance()>0)){
				WBalance.push(this.wallets[i]);
			}
		}
        return WBalance;

    }

}

