/**
 * a mocked class to help you implement the service
 * todo : nothing! this should help you understand the rest
 */
class CryptoWalletService extends WalletService  {

    constructor() {
        super();
    }

}