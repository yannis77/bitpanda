/**
 * a mocked class to help you implement the service
 * todo : nothing! this should help you understand the rest
 */
class FiatWalletService extends WalletService {

    constructor() {
        super();
    }

}
