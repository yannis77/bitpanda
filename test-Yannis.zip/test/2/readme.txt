In this example you should be able - with inheritance - to reuse the methods for FiatWallet and CryptoWallet. 
These are some parts of code you will be working on. 

I tried to keep it as small as possible; you just need to:

1) give type param for "CryptoWalletService" and "FiatWalletService"
2) fix the "WalletService" by giving a generic type param that extends the wallet. if done correctly, implement the methods.
