/**
 * MODELS
 * todo : nothing! this should help you understand the rest
 */
abstract class Wallet {

    id: string = "";
    balance: string = "";

    public getId(): string {
        return this.id;
    }

    public setBalance(balance: number): void {
        this.balance = balance + "";
    }

    public getBalance(): number {
        return +this.balance;
    }

}