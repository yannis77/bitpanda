/**
 * todo : nothing! this should help you understand the rest
 */
class CryptoWallet extends Wallet {

    public constructor() {
        super();
    }
}
