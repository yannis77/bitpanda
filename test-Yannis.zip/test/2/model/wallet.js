"use strict";
/**
 * MODELS
 * todo : nothing! this should help you understand the rest
 */
var Wallet = /** @class */ (function () {
    function Wallet() {
        this.id = "";
        this.balance = "";
    }
    Wallet.prototype.getId = function () {
        return this.id;
    };
    Wallet.prototype.setBalance = function (balance) {
        this.balance = balance + "";
    };
    Wallet.prototype.getBalance = function () {
        return +this.balance;
    };
    return Wallet;
}());
