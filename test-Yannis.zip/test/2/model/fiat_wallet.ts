/**
 * todo : nothing! this should help you understand the rest
 */
class FiatWallet extends Wallet {

    public constructor() {
        super();
    }
}
